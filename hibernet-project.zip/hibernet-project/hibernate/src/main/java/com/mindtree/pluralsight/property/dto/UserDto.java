package com.mindtree.pluralsight.property.dto;

import com.mindtree.pluralsight.property.utils.STATUS;

public class UserDto {

	private String userName;

	private String email;

	private String address;

	private float totalTax;

	private int assessmentYear;

	private int constructedYear;
	
	private STATUS status;
	
	private int builtYear;
	
	private int zoneId;
	
	private int propertyId;

	public UserDto() {
		
	}

	public UserDto(String userName, String email, String address, float totalTax, int assessmentYear,
			int constructedYear, STATUS status, int builtYear, int zoneId, int propertyId) {
		super();
		this.userName = userName;
		this.email = email;
		this.address = address;
		this.totalTax = totalTax;
		this.assessmentYear = assessmentYear;
		this.constructedYear = constructedYear;
		this.status = status;
		this.builtYear = builtYear;
		this.zoneId = zoneId;
		this.propertyId = propertyId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public float getTotalTax() {
		return totalTax;
	}

	public void setTotalTax(float totalTax) {
		this.totalTax = totalTax;
	}

	public int getAssessmentYear() {
		return assessmentYear;
	}

	public void setAssessmentYear(int assessmentYear) {
		this.assessmentYear = assessmentYear;
	}

	public int getConstructedYear() {
		return constructedYear;
	}

	public void setConstructedYear(int constructedYear) {
		this.constructedYear = constructedYear;
	}

	public STATUS getStatus() {
		return status;
	}

	public void setStatus(STATUS status) {
		this.status = status;
	}

	public int getBuiltYear() {
		return builtYear;
	}

	public void setBuiltYear(int builtYear) {
		this.builtYear = builtYear;
	}

	public int getZoneId() {
		return zoneId;
	}

	public void setZoneId(int zoneId) {
		this.zoneId = zoneId;
	}

	public int getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(int propertyId) {
		this.propertyId = propertyId;
	}

}
