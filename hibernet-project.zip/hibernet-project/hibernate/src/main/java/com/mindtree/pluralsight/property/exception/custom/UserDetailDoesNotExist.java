package com.mindtree.pluralsight.property.exception.custom;

import com.mindtree.pluralsight.property.exception.service.PropertyTaxServiceException;

public class UserDetailDoesNotExist extends PropertyTaxServiceException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UserDetailDoesNotExist() {
		super();
	}

	public UserDetailDoesNotExist(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public UserDetailDoesNotExist(String message, Throwable cause) {
		super(message, cause);
	}

	public UserDetailDoesNotExist(String message) {
		super(message);
	}

	public UserDetailDoesNotExist(Throwable cause) {
		super(cause);
	}

}
