package com.mindtree.pluralsight.property.exception.custom;

import com.mindtree.pluralsight.property.exception.service.PropertyTaxServiceException;

public class PropertyDoesNotExist extends PropertyTaxServiceException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PropertyDoesNotExist() {
		super();
	}

	public PropertyDoesNotExist(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public PropertyDoesNotExist(String message, Throwable cause) {
		super(message, cause);
	}

	public PropertyDoesNotExist(String message) {
		super(message);
	}

	public PropertyDoesNotExist(Throwable cause) {
		super(cause);
	}

}
