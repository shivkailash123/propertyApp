package com.mindtree.pluralsight.property.dto;

import java.util.List;

import com.mindtree.pluralsight.property.entity.Zone;
import com.mindtree.pluralsight.property.utils.STATUS;

public class PropertyDto {

	private List<Zone> zones;
	private STATUS status;
	private float amount;

	public PropertyDto() {
		
	}

	public PropertyDto(List<Zone> zones, STATUS status, float amount) {
		super();
		this.zones = zones;
		this.status = status;
		this.amount = amount;
	}

	public List<Zone> getZones() {
		return zones;
	}

	public void setZones(List<Zone> zones) {
		this.zones = zones;
	}

	public STATUS getStatus() {
		return status;
	}

	public void setStatus(STATUS status) {
		this.status = status;
	}

	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "PropertyDto [zones=" + zones + ", status=" + status + ", amount=" + amount + "]";
	}
}
