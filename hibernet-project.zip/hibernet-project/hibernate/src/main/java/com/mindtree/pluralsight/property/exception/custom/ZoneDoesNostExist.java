package com.mindtree.pluralsight.property.exception.custom;

import com.mindtree.pluralsight.property.exception.service.PropertyTaxServiceException;

public class ZoneDoesNostExist extends PropertyTaxServiceException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ZoneDoesNostExist() {
		super();
	}

	public ZoneDoesNostExist(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public ZoneDoesNostExist(String message, Throwable cause) {
		super(message, cause);
	}

	public ZoneDoesNostExist(String message) {
		super(message);
	}

	public ZoneDoesNostExist(Throwable cause) {
		super(cause);
	}

}
