package com.mindtree.pluralsight.property.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.google.gson.Gson;
import com.mindtree.pluralsight.property.dto.UserDto;
import com.mindtree.pluralsight.property.entity.Property;
import com.mindtree.pluralsight.property.entity.Zone;
import com.mindtree.pluralsight.property.entity.ZoneDetails;
import com.mindtree.pluralsight.property.exception.PropertyTaxApplicationException;
import com.mindtree.pluralsight.property.service.PropertyService;
import com.mindtree.pluralsight.property.utils.STATUS;


/**
 * 
 * @author M1057719
 *
 */
@Controller
public class PropertyController {
	
	Map<String, HashMap<String, String>> testMap = new HashMap<String, HashMap<String, String>>();

	@Autowired
	private PropertyService propertyService;
	
	@RequestMapping(value = "/welcome" , method = RequestMethod.GET)
	private String indexPage() {
		return "index";
	}
	
	@RequestMapping(value = "/home" , method = RequestMethod.GET)
	private String indexHomePage() {
		return "error";
	}
	
	@RequestMapping(value = "/assessmentform" , method = RequestMethod.GET)
	private String selfAssessmentForm(Model model) throws PropertyTaxApplicationException {
		UserDto userDto = new UserDto();
		model.addAttribute("userDto",userDto);
		List<Zone> zones=propertyService.fetchZones();
		model.addAttribute("zones", zones);
		List<ZoneDetails> zoneDetails=propertyService.fetchZoneDetails();
		model.addAttribute("zoneDetails", new Gson().toJson(zoneDetails));
		List<Property> properties=propertyService.fetchProperties();
		model.addAttribute("properties", properties);
		model.addAttribute("uav",  new Gson().toJson( properties));
		return "form";
	}
	
	
	
	@RequestMapping(value = "/zonalreport" , method = RequestMethod.GET)
	private String zonalWiseList(Model model) throws PropertyTaxApplicationException {
		Map<String, Map<STATUS, Float>> report = propertyService.getUserDetails();
		model.addAttribute("report", report);
		return "report";
	}
	
	
	@RequestMapping(value = "/saveform" , method = RequestMethod.POST)
	private String getForm(@ModelAttribute(value = "user") UserDto userDto) throws PropertyTaxApplicationException {
		propertyService.addNewUser(userDto);
		return "redirect:/";
	}
	
	@RequestMapping(value = "/calculate" , method = RequestMethod.POST)
	private String calculateTax(@ModelAttribute(value = "user") UserDto userDto) throws PropertyTaxApplicationException {
		propertyService.addNewUser(userDto);
		return "successful";
	}
}
