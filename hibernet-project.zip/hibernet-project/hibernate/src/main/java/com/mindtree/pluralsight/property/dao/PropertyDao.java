package com.mindtree.pluralsight.property.dao;
/**
 * M1057719
 */
import java.util.List;

import com.mindtree.pluralsight.property.entity.Property;
import com.mindtree.pluralsight.property.entity.User;
import com.mindtree.pluralsight.property.entity.Zone;
import com.mindtree.pluralsight.property.entity.ZoneDetails;
import com.mindtree.pluralsight.property.exception.service.PropertyTaxServiceException;

public interface PropertyDao {

	public List<Zone> getZones() throws PropertyTaxServiceException;

	public List<Property> getProperties() throws PropertyTaxServiceException;
	
	public Zone getZone(int zoneId) throws PropertyTaxServiceException;

	public Property getproperty(int propertyId) throws PropertyTaxServiceException;

	public void addUser(User user);

	public List<ZoneDetails> getZoneDetails() throws PropertyTaxServiceException;

	public List<User> getUsers() throws PropertyTaxServiceException;
}
