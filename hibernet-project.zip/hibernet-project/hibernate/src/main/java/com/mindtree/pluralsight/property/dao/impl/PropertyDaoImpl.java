package com.mindtree.pluralsight.property.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.mindtree.pluralsight.property.dao.PropertyDao;
import com.mindtree.pluralsight.property.entity.Property;
import com.mindtree.pluralsight.property.entity.User;
import com.mindtree.pluralsight.property.entity.Zone;
import com.mindtree.pluralsight.property.entity.ZoneDetails;
import com.mindtree.pluralsight.property.exception.custom.PropertyDoesNotExist;
import com.mindtree.pluralsight.property.exception.custom.UserDetailDoesNotExist;
import com.mindtree.pluralsight.property.exception.custom.ZoneDetailDoesNotExist;
import com.mindtree.pluralsight.property.exception.custom.ZoneDoesNostExist;
import com.mindtree.pluralsight.property.exception.service.PropertyTaxServiceException;

/**
 * 
 * @author M1057719
 *
 */
@Repository
public class PropertyDaoImpl implements PropertyDao {

	@Autowired
	private HibernateTemplate hibernateTeamplate;

	@Override
	public List<Zone> getZones() throws PropertyTaxServiceException {
		List<Zone> zones = hibernateTeamplate.loadAll(Zone.class);
		if(zones.isEmpty()) {
			throw new ZoneDoesNostExist("No zone are present");
		}
		return zones;
	}

	@Override
	public List<Property> getProperties() throws PropertyTaxServiceException {
		List<Property> properties = hibernateTeamplate.loadAll(Property.class);
		if(properties.isEmpty()) {
			throw new PropertyDoesNotExist("No property is present");
		}
		return properties;
	}

	@Override
	public Zone getZone(int zoneId) throws PropertyTaxServiceException {
		Zone zone = hibernateTeamplate.load(Zone.class, zoneId);
		if(zone == null) {
			throw new ZoneDoesNostExist("Zone with the id " + zoneId + " not found");
		}
		return zone;
	}

	@Override
	public Property getproperty(int propertyId) throws PropertyTaxServiceException {
		Property property = hibernateTeamplate.load(Property.class, propertyId); // or with Sessionfactory
		if(property == null) {
			throw new PropertyDoesNotExist("Zone with the id " + propertyId + " not found");
		}
		return property; 
	}

	@Override
	public void addUser(User user) {
		 hibernateTeamplate.save(user);
	}

	@Override
	public List<ZoneDetails> getZoneDetails() throws PropertyTaxServiceException {
		List<ZoneDetails> zoneDetails = hibernateTeamplate.loadAll(ZoneDetails.class);
		if(zoneDetails.isEmpty()) {
			throw new ZoneDetailDoesNotExist("ZoneDetails List Is Empty");
		}
		return zoneDetails; 
	}

	@Override
	public List<User> getUsers() throws PropertyTaxServiceException {
		List<User> users = hibernateTeamplate.loadAll(User.class);
		if(users.isEmpty()) {
			throw new UserDetailDoesNotExist("List Is Empty");
		}
		return users;
	}

}
