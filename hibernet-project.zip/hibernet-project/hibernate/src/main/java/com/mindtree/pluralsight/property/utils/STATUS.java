package com.mindtree.pluralsight.property.utils;

public enum STATUS {
	Tenanted, Owner
}
