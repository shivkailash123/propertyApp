package com.mindtree.pluralsight.property.exception.custom;

import com.mindtree.pluralsight.property.exception.service.PropertyTaxServiceException;

public class ZoneDetailDoesNotExist extends PropertyTaxServiceException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ZoneDetailDoesNotExist() {
		super();
	}

	public ZoneDetailDoesNotExist(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public ZoneDetailDoesNotExist(String message, Throwable cause) {
		super(message, cause);
	}

	public ZoneDetailDoesNotExist(String message) {
		super(message);
	}

	public ZoneDetailDoesNotExist(Throwable cause) {
		super(cause);
	}

}
