package com.mindtree.pluralsight.property.service.impl;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.pluralsight.property.dao.PropertyDao;
import com.mindtree.pluralsight.property.dto.UserDto;
import com.mindtree.pluralsight.property.entity.Property;
import com.mindtree.pluralsight.property.entity.User;
import com.mindtree.pluralsight.property.entity.Zone;
import com.mindtree.pluralsight.property.entity.ZoneDetails;
import com.mindtree.pluralsight.property.exception.service.PropertyTaxServiceException;
import com.mindtree.pluralsight.property.service.PropertyService;
import com.mindtree.pluralsight.property.utils.STATUS;

/**
 * 
 * @author M1057719
 *
 */
@Service
@Transactional
public class PropertyServiceImpl implements PropertyService {
	
	private float amount = 0;

	@Autowired
	private PropertyDao propertyDao;

	@Override
	@Transactional
	public List<Zone> fetchZones() throws PropertyTaxServiceException {
		return propertyDao.getZones();
	}

	@Override
	@Transactional
	public List<Property> fetchProperties() throws PropertyTaxServiceException {
		return propertyDao.getProperties();
	}

	@Override
	@Transactional
	public void addNewUser(UserDto userDto) throws PropertyTaxServiceException {
		User user = new User();
		user.setAddress(userDto.getAddress());
		user.setAssessmentYear(userDto.getAssessmentYear());
		user.setBuiltYear(userDto.getBuiltYear());
		user.setConstructedYear(userDto.getConstructedYear());
		Zone zone = propertyDao.getZone(userDto.getZoneId());
		user.setZone(zone);
		user.setEmail(userDto.getEmail());
		user.setTotalTax(userDto.getTotalTax());
		Property property = propertyDao.getproperty(userDto.getPropertyId());
		user.setProperty(property);
		user.setUserName(userDto.getUserName());
		user.setStatus(userDto.getStatus());
		
		
		propertyDao.addUser(user);
	}

	@Override
	@Transactional
	public List<ZoneDetails> fetchZoneDetails() throws PropertyTaxServiceException {
		return propertyDao.getZoneDetails();
	}

	@Override
	@Transactional
	public Map<String, Map<STATUS, Float>> getUserDetails() throws PropertyTaxServiceException {
		List<User> users=propertyDao.getUsers();
		List<Zone> zones= propertyDao.getZones();
		List<STATUS> statuses = Arrays.asList(STATUS.values());
		Map<String, Map<STATUS, Float> > report = new HashMap<String, Map<STATUS, Float>>();
		zones.forEach(zone -> {
			Map<STATUS, Float> amountMap = new HashMap <STATUS, Float>();
			statuses.forEach(status -> {
				for(User user : users) {
					if(user.getZone().getZoneName().equals(zone.getZoneName())  && user.getStatus().ordinal() == status.ordinal()) {
						amount += user.getTotalTax();
					}
					
				}
				amountMap.put(status,amount);
				amount = 0;
			});
			report.put(zone.getZoneName(), amountMap);
		});
		return report;
	}
}
