package com.mindtree.pluralsight.property.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import com.mindtree.pluralsight.property.utils.STATUS;

/**
 * 
 * @author M1057719
 *
 */
@Entity
public class User implements Comparable<User> {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int userId;

	private String userName;

	private String email;

	private String address;

	private float totalTax;

	private int assessmentYear;
	
	private int constructedYear;
	
	private int builtYear;

	@OneToOne(cascade = CascadeType.ALL)
	private Zone zone;

	@OneToOne(cascade = CascadeType.ALL)
	private Property property;

	private STATUS status;
	
	public User() {

	}
	
	public User(int userId, String userName, String email, String address, float totalTax, int assessmentYear,
			int constructedYear, int builtYear, Zone zone, Property property, STATUS status) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.email = email;
		this.address = address;
		this.totalTax = totalTax;
		this.assessmentYear = assessmentYear;
		this.constructedYear = constructedYear;
		this.builtYear = builtYear;
		this.zone = zone;
		this.property = property;
		this.status = status;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public float getTotalTax() {
		return totalTax;
	}

	public void setTotalTax(float totalTax) {
		this.totalTax = totalTax;
	}

	public int getAssessmentYear() {
		return assessmentYear;
	}

	public void setAssessmentYear(int assessmentYear) {
		this.assessmentYear = assessmentYear;
	}

	public Zone getZone() {
		return zone;
	}

	public void setZone(Zone zone) {
		this.zone = zone;
	}

	public Property getProperty() {
		return property;
	}

	public void setProperty(Property property) {
		this.property = property;
	}

	public STATUS getStatus() {
		return status;
	}

	public void setStatus(STATUS status) {
		this.status = status;
	}

	public int getConstructedYear() {
		return constructedYear;
	}

	public void setConstructedYear(int constructedYear) {
		this.constructedYear = constructedYear;
	}

	public int getBuiltYear() {
		return builtYear;
	}

	public void setBuiltYear(int builtYear) {
		this.builtYear = builtYear;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		result = prime * result + assessmentYear;
		result = prime * result + builtYear;
		result = prime * result + constructedYear;
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((property == null) ? 0 : property.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result + Float.floatToIntBits(totalTax);
		result = prime * result + userId;
		result = prime * result + ((userName == null) ? 0 : userName.hashCode());
		result = prime * result + ((zone == null) ? 0 : zone.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (assessmentYear != other.assessmentYear)
			return false;
		if (builtYear != other.builtYear)
			return false;
		if (constructedYear != other.constructedYear)
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (property == null) {
			if (other.property != null)
				return false;
		} else if (!property.equals(other.property))
			return false;
		if (status != other.status)
			return false;
		if (Float.floatToIntBits(totalTax) != Float.floatToIntBits(other.totalTax))
			return false;
		if (userId != other.userId)
			return false;
		if (userName == null) {
			if (other.userName != null)
				return false;
		} else if (!userName.equals(other.userName))
			return false;
		if (zone == null) {
			if (other.zone != null)
				return false;
		} else if (!zone.equals(other.zone))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", email=" + email + ", address=" + address
				+ ", totalTax=" + totalTax + ", assessmentYear=" + assessmentYear + ", constructedYear="
				+ constructedYear + ", builtYear=" + builtYear + ", zone=" + zone + ", property=" + property
				+ ", status=" + status + "]";
	}

	@Override
	public int compareTo(User user) {
		return this.userId - user.getUserId();
	}
	
	
}
