package com.mindtree.pluralsight.property.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.pluralsight.property.entity.Property;
import com.mindtree.pluralsight.property.entity.User;
import com.mindtree.pluralsight.property.entity.Zone;
import com.mindtree.pluralsight.property.entity.ZoneDetails;

/**
 * 
 * @author M1057719
 *
 */
@RestController
@RequestMapping("/basic")
public class BasicController {

	@Autowired
	private HibernateTemplate hibernateTemplate;

	@GetMapping("/test")
	public String testBasic() {
		return "CHECK : FORM PROPERTY APP";
	}

	@GetMapping("/zone")
	public List<Zone> getZones() {
		List<Zone> zones = hibernateTemplate.loadAll(Zone.class);
		return hibernateTemplate.loadAll(Zone.class);
	}

	@GetMapping("/property")
	public List<Property> getProperties() {
		List<Property> zones = hibernateTemplate.loadAll(Property.class);
		return hibernateTemplate.loadAll(Property.class);
	}

	@GetMapping("/zonedetails")
	public List<ZoneDetails> getZoneDetails() {
		List<ZoneDetails> zonedetls = hibernateTemplate.loadAll(ZoneDetails.class);
		return hibernateTemplate.loadAll(ZoneDetails.class);
	}

	@PostMapping("/addzone")
	public String addZone(@RequestBody ZoneDetails zoneDet) {
		 hibernateTemplate.save(zoneDet);
		return "Inserted";
	}
	
	@GetMapping("/fetchUser")
	public List<User> fetchUsers(){
		return hibernateTemplate.loadAll(User.class);
	}

}
