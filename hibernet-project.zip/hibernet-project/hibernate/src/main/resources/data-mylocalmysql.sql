
 INSERT INTO `propertytax`.`property` (`propertyId`, `description`) VALUES ('1', 'RCC buildings with cement or red-oxide flooring');
 INSERT INTO `propertytax`.`zone` (`zoneId`, `zoneName`) VALUES ('1', 'Zone A');
 INSERT INTO `propertytax`.`zonedetails` (`id`, `rate`, `status`, `property_propertyId`, `zone_zoneId`) VALUES ('1', '1200', '1', '1', '1');