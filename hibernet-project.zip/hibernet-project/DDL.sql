CREATE DATABASE `propertytax` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */;
CREATE TABLE `property` (
  `propertyId` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`propertyId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
CREATE TABLE `user` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `address` varchar(255) DEFAULT NULL,
  `assessmentYear` int(11) NOT NULL,
  `builtYear` int(11) NOT NULL,
  `constructedYear` int(11) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `totalTax` float NOT NULL,
  `userName` varchar(255) DEFAULT NULL,
  `property_propertyId` int(11) DEFAULT NULL,
  `zone_zoneId` int(11) DEFAULT NULL,
  PRIMARY KEY (`userId`),
  KEY `FKdou3ad3t208sgkplgb7hq9uj4` (`property_propertyId`),
  KEY `FK8i9rtexa0tyb846n7jw7v62ge` (`zone_zoneId`),
  CONSTRAINT `FK8i9rtexa0tyb846n7jw7v62ge` FOREIGN KEY (`zone_zoneId`) REFERENCES `zone` (`zoneId`),
  CONSTRAINT `FKdou3ad3t208sgkplgb7hq9uj4` FOREIGN KEY (`property_propertyId`) REFERENCES `property` (`propertyId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
CREATE TABLE `zone` (
  `zoneId` int(11) NOT NULL AUTO_INCREMENT,
  `zoneName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`zoneId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
CREATE TABLE `zonedetails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rate` float NOT NULL,
  `status` int(11) DEFAULT NULL,
  `property_propertyId` int(11) DEFAULT NULL,
  `zone_zoneId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKo3yrv1orw27cikykoa839sf3n` (`property_propertyId`),
  KEY `FKklj20243jbvan0re1t5vl4cvp` (`zone_zoneId`),
  CONSTRAINT `FKklj20243jbvan0re1t5vl4cvp` FOREIGN KEY (`zone_zoneId`) REFERENCES `zone` (`zoneId`),
  CONSTRAINT `FKo3yrv1orw27cikykoa839sf3n` FOREIGN KEY (`property_propertyId`) REFERENCES `property` (`propertyId`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
